﻿namespace ZAZ_Demo
{
    partial class ZAZDemo
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ZAZDemo));
            this.fpbmp = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.labinfo = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.fpdb = new System.Windows.Forms.TextBox();
            this.btn_dbdata = new System.Windows.Forms.Button();
            this.btn_fingercount = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.btn_match = new System.Windows.Forms.Button();
            this.btn_empty = new System.Windows.Forms.Button();
            this.btn_del = new System.Windows.Forms.Button();
            this.btn_eroll = new System.Windows.Forms.Button();
            this.btn_getoneimg = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textcom = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_closeusb = new System.Windows.Forms.Button();
            this.btn_usb = new System.Windows.Forms.Button();
            this.btn_closecom = new System.Windows.Forms.Button();
            this.btn_com = new System.Windows.Forms.Button();
            this.BtnPCmatch = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.fpbmp)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // fpbmp
            // 
            this.fpbmp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.fpbmp.Location = new System.Drawing.Point(6, 20);
            this.fpbmp.Name = "fpbmp";
            this.fpbmp.Size = new System.Drawing.Size(256, 288);
            this.fpbmp.TabIndex = 0;
            this.fpbmp.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.fpbmp);
            this.groupBox1.Location = new System.Drawing.Point(2, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(269, 315);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "指纹图像预览区";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.labinfo);
            this.groupBox2.Location = new System.Drawing.Point(277, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(335, 153);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "提示";
            // 
            // labinfo
            // 
            this.labinfo.AutoSize = true;
            this.labinfo.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labinfo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.labinfo.Location = new System.Drawing.Point(6, 17);
            this.labinfo.Name = "labinfo";
            this.labinfo.Size = new System.Drawing.Size(40, 16);
            this.labinfo.TabIndex = 8;
            this.labinfo.Text = "info";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.BtnPCmatch);
            this.groupBox3.Controls.Add(this.fpdb);
            this.groupBox3.Controls.Add(this.btn_dbdata);
            this.groupBox3.Controls.Add(this.btn_fingercount);
            this.groupBox3.Controls.Add(this.btn_search);
            this.groupBox3.Controls.Add(this.btn_match);
            this.groupBox3.Controls.Add(this.btn_empty);
            this.groupBox3.Controls.Add(this.btn_del);
            this.groupBox3.Controls.Add(this.btn_eroll);
            this.groupBox3.Controls.Add(this.btn_getoneimg);
            this.groupBox3.Location = new System.Drawing.Point(277, 171);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(335, 264);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "基本操作";
            // 
            // fpdb
            // 
            this.fpdb.AcceptsTab = true;
            this.fpdb.Location = new System.Drawing.Point(204, 29);
            this.fpdb.Multiline = true;
            this.fpdb.Name = "fpdb";
            this.fpdb.Size = new System.Drawing.Size(125, 118);
            this.fpdb.TabIndex = 9;
            // 
            // btn_dbdata
            // 
            this.btn_dbdata.Location = new System.Drawing.Point(106, 122);
            this.btn_dbdata.Name = "btn_dbdata";
            this.btn_dbdata.Size = new System.Drawing.Size(92, 25);
            this.btn_dbdata.TabIndex = 8;
            this.btn_dbdata.Text = "查看指纹库";
            this.btn_dbdata.UseVisualStyleBackColor = true;
            this.btn_dbdata.Click += new System.EventHandler(this.btn_dbdata_Click);
            // 
            // btn_fingercount
            // 
            this.btn_fingercount.Location = new System.Drawing.Point(106, 91);
            this.btn_fingercount.Name = "btn_fingercount";
            this.btn_fingercount.Size = new System.Drawing.Size(92, 25);
            this.btn_fingercount.TabIndex = 7;
            this.btn_fingercount.Text = "指纹总数";
            this.btn_fingercount.UseVisualStyleBackColor = true;
            this.btn_fingercount.Click += new System.EventHandler(this.btn_fingercount_Click);
            // 
            // btn_search
            // 
            this.btn_search.Location = new System.Drawing.Point(106, 60);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(92, 25);
            this.btn_search.TabIndex = 6;
            this.btn_search.Text = "搜索指纹";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // btn_match
            // 
            this.btn_match.Location = new System.Drawing.Point(106, 29);
            this.btn_match.Name = "btn_match";
            this.btn_match.Size = new System.Drawing.Size(92, 25);
            this.btn_match.TabIndex = 5;
            this.btn_match.Text = "比对指纹";
            this.btn_match.UseVisualStyleBackColor = true;
            this.btn_match.Click += new System.EventHandler(this.btn_match_Click);
            // 
            // btn_empty
            // 
            this.btn_empty.Location = new System.Drawing.Point(8, 122);
            this.btn_empty.Name = "btn_empty";
            this.btn_empty.Size = new System.Drawing.Size(92, 25);
            this.btn_empty.TabIndex = 4;
            this.btn_empty.Text = "清空指纹";
            this.btn_empty.UseVisualStyleBackColor = true;
            this.btn_empty.Click += new System.EventHandler(this.btn_empty_Click);
            // 
            // btn_del
            // 
            this.btn_del.Location = new System.Drawing.Point(8, 91);
            this.btn_del.Name = "btn_del";
            this.btn_del.Size = new System.Drawing.Size(92, 25);
            this.btn_del.TabIndex = 3;
            this.btn_del.Text = "删除指纹";
            this.btn_del.UseVisualStyleBackColor = true;
            this.btn_del.Click += new System.EventHandler(this.btn_del_Click);
            // 
            // btn_eroll
            // 
            this.btn_eroll.Location = new System.Drawing.Point(8, 60);
            this.btn_eroll.Name = "btn_eroll";
            this.btn_eroll.Size = new System.Drawing.Size(92, 25);
            this.btn_eroll.TabIndex = 2;
            this.btn_eroll.Text = "注册指纹";
            this.btn_eroll.UseVisualStyleBackColor = true;
            this.btn_eroll.Click += new System.EventHandler(this.btn_eroll_Click);
            // 
            // btn_getoneimg
            // 
            this.btn_getoneimg.Location = new System.Drawing.Point(8, 29);
            this.btn_getoneimg.Name = "btn_getoneimg";
            this.btn_getoneimg.Size = new System.Drawing.Size(92, 25);
            this.btn_getoneimg.TabIndex = 1;
            this.btn_getoneimg.Text = "获取一张图像";
            this.btn_getoneimg.UseVisualStyleBackColor = true;
            this.btn_getoneimg.Click += new System.EventHandler(this.btn_getoneimg_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox2);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.textcom);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.btn_closeusb);
            this.groupBox4.Controls.Add(this.btn_usb);
            this.groupBox4.Controls.Add(this.btn_closecom);
            this.groupBox4.Controls.Add(this.btn_com);
            this.groupBox4.Location = new System.Drawing.Point(3, 325);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(268, 110);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "提示";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(179, 49);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(46, 21);
            this.textBox2.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(131, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "波特率:";
            // 
            // textcom
            // 
            this.textcom.Location = new System.Drawing.Point(63, 49);
            this.textcom.Name = "textcom";
            this.textcom.Size = new System.Drawing.Size(46, 21);
            this.textcom.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "串  口:";
            // 
            // btn_closeusb
            // 
            this.btn_closeusb.Location = new System.Drawing.Point(101, 81);
            this.btn_closeusb.Name = "btn_closeusb";
            this.btn_closeusb.Size = new System.Drawing.Size(75, 23);
            this.btn_closeusb.TabIndex = 3;
            this.btn_closeusb.Text = "关闭USB";
            this.btn_closeusb.UseVisualStyleBackColor = true;
            this.btn_closeusb.Click += new System.EventHandler(this.btn_closeusb_Click);
            // 
            // btn_usb
            // 
            this.btn_usb.Location = new System.Drawing.Point(9, 81);
            this.btn_usb.Name = "btn_usb";
            this.btn_usb.Size = new System.Drawing.Size(75, 23);
            this.btn_usb.TabIndex = 2;
            this.btn_usb.Text = "打开USB";
            this.btn_usb.UseVisualStyleBackColor = true;
            this.btn_usb.Click += new System.EventHandler(this.btn_usb_Click);
            // 
            // btn_closecom
            // 
            this.btn_closecom.Location = new System.Drawing.Point(101, 20);
            this.btn_closecom.Name = "btn_closecom";
            this.btn_closecom.Size = new System.Drawing.Size(75, 23);
            this.btn_closecom.TabIndex = 1;
            this.btn_closecom.Text = "关闭串口";
            this.btn_closecom.UseVisualStyleBackColor = true;
            this.btn_closecom.Click += new System.EventHandler(this.btn_closecom_Click);
            // 
            // btn_com
            // 
            this.btn_com.Location = new System.Drawing.Point(9, 20);
            this.btn_com.Name = "btn_com";
            this.btn_com.Size = new System.Drawing.Size(75, 23);
            this.btn_com.TabIndex = 0;
            this.btn_com.Text = "打开串口";
            this.btn_com.UseVisualStyleBackColor = true;
            this.btn_com.Click += new System.EventHandler(this.btn_com_Click);
            // 
            // BtnPCmatch
            // 
            this.BtnPCmatch.Location = new System.Drawing.Point(9, 174);
            this.BtnPCmatch.Name = "BtnPCmatch";
            this.BtnPCmatch.Size = new System.Drawing.Size(75, 23);
            this.BtnPCmatch.TabIndex = 10;
            this.BtnPCmatch.Text = "PC比对";
            this.BtnPCmatch.UseVisualStyleBackColor = true;
            this.BtnPCmatch.Click += new System.EventHandler(this.BtnPCmatch_Click);
            // 
            // ZAZDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(624, 441);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ZAZDemo";
            this.Text = "ZAZ_Demo v3.2";
            this.Load += new System.EventHandler(this.ZAZDemo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.fpbmp)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox fpbmp;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textcom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_closeusb;
        private System.Windows.Forms.Button btn_usb;
        private System.Windows.Forms.Button btn_closecom;
        private System.Windows.Forms.Button btn_com;
        private System.Windows.Forms.Label labinfo;
        private System.Windows.Forms.Button btn_dbdata;
        private System.Windows.Forms.Button btn_fingercount;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_match;
        private System.Windows.Forms.Button btn_empty;
        private System.Windows.Forms.Button btn_del;
        private System.Windows.Forms.Button btn_eroll;
        private System.Windows.Forms.Button btn_getoneimg;
        private System.Windows.Forms.TextBox fpdb;
        private System.Windows.Forms.Button BtnPCmatch;
    }
}

