﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

using System.Runtime.InteropServices;//与调用DLL相关
using System.Threading;
using System.IO;
 
namespace ZAZ_Demo
{
    public partial class ZAZDemo : Form
    {

        IntPtr hHandle = new IntPtr();
        bool isusb = true;
        int m_baud = 57600;
        int m_com = 0;
        int m_Fpid = 0;
        public const int IMAGE_SIZE = (256 * 288);
        public ZAZDemo()
        {
            InitializeComponent();
        }

        private void ZAZDemo_Load(object sender, EventArgs e)
        {

        }

        private void btn_com_Click(object sender, EventArgs e)
        {
            int ret = 0;
            int devce_usb = 0;
            uint nDevAddr = 0xffffffff;
            /****************打开设备*********/

            m_baud = 57600;
            m_com = Convert.ToInt32(textcom.Text);
            ret = connect_com(m_com, 57600);
            if (ret != 0)
            {
                m_baud = 19200;
                ret = connect_com(m_com, 19200);
            }
            if (ret != 0)
            {
                m_baud = 9600;
                ret = connect_com(m_com, 9600);
            }
            if (ret != 0)
            {
                m_baud = 115200;
                ret = connect_com(m_com, 115200);
            }
            if (ret != 0)
            {
                m_baud = 460800;
                ret = connect_com(m_com, 460800);
            }
            if (ret != 0)
            {
                m_baud = 38400;
                ret = connect_com(m_com, 38400);
            }
            if (ret != 0) return;

            isusb = false;
            showFpdb();
            ShowPara();
            connect_close();






        }

        private void btn_usb_Click(object sender, EventArgs e)
        {
            int ret = 0;
            int devce_usb = 0;
            uint nDevAddr = 0xffffffff;

          //  Fingerdll.ZAZCloseDeviceEx(hHandle);
           
            ret = connect_usb();
            if (ret != 0)
            { connect_close(); return; }
            isusb = true;
            showFpdb();
            ShowPara();
            connect_close();
            //ShowInfomation("打开usb成功" );

        }

        void ShowPara()
        {
            int ret;
            byte[] iParTable = new byte[512];
            int nLevel, nPackSize, nBaud;
            int i;
            uint nDevAddr = 0xffffffff;
            ret = Fingerdll.ZAZReadInfPage(hHandle, nDevAddr, ref iParTable[0]);
            if (ret != 0)
                return;
            string strTemp, strPara = "";
            long mCap;
            mCap = (iParTable[4] << 8) + iParTable[5];
            strTemp = "指纹库大小：" + mCap.ToString() + "\r\n";
            strPara += strTemp;

            nLevel = (iParTable[6] << 8) + iParTable[7];
            strTemp = "安全等级：" + nLevel.ToString() + "\r\n";
            strPara += strTemp;

            nPackSize = (iParTable[12] << 8) + iParTable[13];
            strTemp = "数据包大小：" + (System.Math.Pow(2.0, nPackSize) * 32).ToString() + "bytes\r\n";
            strPara += strTemp;


            nBaud = (iParTable[14] << 8) + iParTable[15];
            strTemp = "波特率：" + (nBaud * 9600).ToString() + "bps\r\n";
            strPara += strTemp;


            strPara += "产品型号：";
            byte[] sss = new byte[8];
            for (i = 28; i < 28 + 8; i++)
            {
                sss[i - 28] = iParTable[i];
                //  strPara += strTemp;
            }
            strTemp = System.Text.Encoding.ASCII.GetString(sss);
            strPara += strTemp;
            strPara += "\r\n";
            strPara += "软件版本:";
            for (i = 36; i < 36 + 8; i++)
            {
                sss[i - 36] = iParTable[i];

            }
            strTemp = System.Text.Encoding.ASCII.GetString(sss);
            strPara += strTemp;
            strPara += "\r\n";
            strPara += "厂家名称：";
            for (i = 44; i < 44 + 8; i++)
            {
                sss[i - 44] = iParTable[i];
            }
            strTemp = System.Text.Encoding.ASCII.GetString(sss);
            strPara += strTemp;
            strPara += "\r\n";

            if (isusb)
            {
                strPara += "打开USB成功 ";
            }
            else
            {
                strPara += "打开串口成功 ";
            }



            ShowInfomation(strPara);

        }
        int showFpdb()
        {
            int ret = 0;
            uint nDevAddr = 0xffffffff;
            byte[] indextable = new byte[32];

            string tmp = "";
            int temp, ttt;
            for (int moban = 0; moban < 4; moban++)
            {
                ret = Fingerdll.ZAZReadIndexTable(hHandle, nDevAddr, moban, ref indextable[0]);
                if (ret == 0)
                {
                    for (int ari = 0; ari < 32; ari++)
                    {
                        for (int i = 0; i < 8; i++)
                        {
                            temp = indextable[ari];
                            ttt = (0x01 << i);
                            temp &= ttt;
                            if (temp != 0)
                            {

                                int m_Addr;
                                m_Addr = moban * 32 * 8 + ari * 8 + i;
                                tmp += m_Addr.ToString() + ",";

                            }
                        }
                    }
                }
                else
                {
                    ShowInfomation(Fingerdll.ZAZErr2Str(ret));
                    return 1;
                }
            }
            this.Invoke((EventHandler)(delegate { fpdb.Text = tmp; }));

            return 1;
        }
        private void ShowInfomation(string strInfo)
        {

            this.Invoke((EventHandler)(delegate { labinfo.Text = strInfo; }));

        }
        private void connect_close()
        {
            Fingerdll.ZAZCloseDeviceEx(hHandle);

        }


        int connect_com(int icom, int band)
        {
            int ret = 0;
            int devce_usb = 0;

            byte[] iPwd = new byte[4];
            UInt32 nDevAddr = 0xffffffff;
            IntPtr hHandle1 = new IntPtr();
            Fingerdll.ZAZCloseDeviceEx(hHandle);
            ret = Fingerdll.ZAZOpenDeviceEx(ref hHandle, 1, icom, band / 9600, 2, 0);
            if (ret == 0)
            {
                ret = Fingerdll.ZAZVfyPwd(hHandle, nDevAddr, ref iPwd[0]);
                if (ret == 0)
                {
                    //	ShowInfomation("指昂串口指纹设备",RGB(0,0,255));
                    return 0;
                }
                else
                {
                    ShowInfomation("打开COM设备失败,请查看设备是否连接");
                    connect_close();
                    return 1;
                }
            }
            else
            {
                Fingerdll.ZAZCloseDeviceEx(hHandle);	//此处解除串口占用
                ShowInfomation("串口被占用，请检查串口号及波特率");
                return 2;
            }
        }

        private int connect_usb()
        {
            int ret = 0;
            int devce_usb = 0;
            byte[] iPwd = new byte[4];
            uint nDevAddr = 0xffffffff;
           // Fingerdll.ZAZCloseDeviceEx(hHandle);
            ret = Fingerdll.ZAZOpenDeviceEx(ref hHandle, 0, 0, 0, 2, 0);
            if (ret == 0)
            {
                devce_usb = 1;  //有驱
            }
            ret = Fingerdll.ZAZOpenDeviceEx(ref hHandle, 0, 0, 0, 2, 0);
            if (ret == 0)
            {
                devce_usb = 1;  //有驱
            }
     
            ret = Fingerdll.ZAZOpenDeviceEx(ref hHandle, 2, 0, 0, 2, 0);
            if (ret == 0)
            {
                devce_usb = 2;  //无驱
            }

            if (devce_usb == 1)
            {
                if (Fingerdll.ZAZVfyPwd(hHandle, nDevAddr, ref iPwd[0]) == 0)
                {
                    //	ShowInfomation("指昂有驱USB指纹设备",RGB(0,0,255));	
                    return 0;
                }
                else
                { ShowInfomation("打开USB设备失败,请查看设备是否连接"); return 1; }

            }
            else if (devce_usb == 2)
            {
                if (Fingerdll.ZAZVfyPwd(hHandle, nDevAddr, ref iPwd[0]) == 0)
                {
                    //	ShowInfomation("指昂无驱USB指纹设备",RGB(0,0,255));
                    return 0;
                }
                else
                { ShowInfomation("打开USB设备失败,请查看设备是否连接"); return 1; }
            }
            else
            {
                ShowInfomation("打开USB设备失败,请查看设备是否连接");
                return 1;
                //usb设备请查看“设备管理器”
            }


        }

        private void btn_closeusb_Click(object sender, EventArgs e)
        {
            Fingerdll.ZAZCloseDeviceEx(hHandle);
            ShowInfomation("关闭usb成功");
        }

        private void btn_closecom_Click(object sender, EventArgs e)
        {
            Fingerdll.ZAZCloseDeviceEx(hHandle);
            ShowInfomation("关闭COM成功");
        }

        private void btn_getoneimg_Click(object sender, EventArgs e)
        {

            startGetoneimg();//开启获取指纹图像 
          
        }
        private void startGetoneimg()
        {
            Thread thread = new Thread(new ThreadStart(F_Getoneimg));
            thread.Start();
            thread.IsBackground = true;
            if (!thread.IsAlive)
            {
                Thread.Sleep(100);
            }
        }

        private unsafe void F_Getoneimg()
        {
            // TODO: Add your control notification handler code here
            int ret = 0;
            int devce_usb = 0;
            UInt32 nDevAddr = 0xffffffff;

            Fingerdll.ZAZCloseDeviceEx(hHandle);
            /****************打开设备*********/
            //usb类型
            if (isusb)
            {
                ret = connect_usb();
                if (ret != 0)
                { return; }
            }
            else
            {
                m_com = Convert.ToInt32(textcom.Text);
                ret = connect_com(m_com, m_baud);
                if (ret != 0)
                { return; }
            }

            getimg(hHandle, nDevAddr, 1);
            connect_close();   
        }

        int getimg(IntPtr hHandle, UInt32 nDevAddr, int buffer)
        {
            int ret = 0;
            byte[] ImgData = new byte[IMAGE_SIZE];
            int ImgLen = 0;
            string strFile = "";
            string sPath = "";
            int iBuffer = buffer;
            int timeout = 20;   //定义等待超时
            /****************获取图像*********/
            timeout = 20;
        BEIG1:
            ret = Fingerdll.ZAZGetImage(hHandle, nDevAddr);  //获取图象 
            if (ret == 2)
            { ShowInfomation("请将手指平放在传感器上..."); }
            else if (ret == 0)
            { ShowInfomation("获取图像成功..."); }
            else
            { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); return 0; }
            if (ret == 2)
            { //超时判断

                string strTemp;

                ShowInfomation("等待手指平放在传感器上-" + timeout.ToString() + "秒");
                if (timeout < 0)
                { ShowInfomation("等待超时"); return 0; }
                timeout--;
                Thread.Sleep(10); goto BEIG1;
            }
            //////////////////////////////////////////////////////////////////////////
            //不涉及图像，下面可以省略
            /****************上传图像*********/
         //   if (isusb)
            {


                ShowInfomation("正在上传图像请等待...");
                ret = Fingerdll.ZAZUpImage(hHandle, nDevAddr, ref ImgData[0], ref ImgLen);  //上传图象
                if (ret != 0)
                { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); return 0; }
                strFile = "c:\\ZAZFinger.bmp";
                ret = Fingerdll.ZAZImgData2BMP(ref ImgData[0], strFile);
                if (ret != 0)
                { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); return 0; }
                ShowImage(strFile);
                ShowInfomation("获取图像成功...");

            }
            return 1;

        }


        private void ShowImage(string bmpFileName)
        {

            this.Invoke((EventHandler)(delegate
            {
                FileStream pFileStream = new FileStream(bmpFileName, FileMode.Open, FileAccess.Read);
                fpbmp.Image = Image.FromStream(pFileStream);
                pFileStream.Close();
                pFileStream.Dispose();

            }
         ));
        }

        private void btn_eroll_Click(object sender, EventArgs e)
        {
            IDD_Intput inputsd = new IDD_Intput();
            inputsd.ShowDialog();
            string strTemp = "";
            strTemp = inputsd.strTemp;
            if (strTemp != "") //显示输入框，接收信息，确定用户是否确定输入
            {
                string cs; //用于接收数据 
                if (isNumberic(strTemp, out m_Fpid))
                { }
                else
                {
                    MessageBox.Show("请输入数字");
                    return;
                }
            }
            else
            {
                return;
            }
            starterollhread();//开启获取指纹图像和特征的线程
        }
        private void starterollhread()
        {
            Thread thread = new Thread(new ThreadStart(erollfp));
            thread.Start();
            thread.IsBackground = true;
            if (!thread.IsAlive)
            {
                Thread.Sleep(100);
            }
        }
        private unsafe void erollfp()
        {
            int ret = 0;
            int devce_usb = 0;
            UInt32 nDevAddr = 0xffffffff;
            //	unsigned char ImgData [IMAGE_SIZE];
            int ImgLen = 0;
            string strFile = "";
            string sPath = "";
            int iBuffer = 0;
            int timeout = 20;   //定义等待超时
            int m_Addr = 1;//本例将指纹存储在设备库位置1中
            Fingerdll.ZAZCloseDeviceEx(hHandle);

            if (isusb)
            {
                ret = connect_usb();
                if (ret != 0)
                { goto ENDERR; }
            }
            else
            {
                m_com = Convert.ToInt32(textcom.Text);
                ret = connect_com(m_com, m_baud);
                if (ret != 0)
                { goto ENDERR; }
            }
            //3获取指纹图像  4.上传指纹图像(可省略) 5.显示指纹图像(可省略)  6.生成特征A  
            if (getchar(hHandle, nDevAddr, 1) != 1)
            { goto ENDERR; }
            Thread.Sleep(200);
            //7.获取指纹图像  8.上传指纹图像(可省略) 9.显示指纹图像(可省略) 10.生成特征B
            if (getchar(hHandle, nDevAddr, 2) != 1)
            { goto ENDERR; }

            //////////////////////////////////////////////////////////////////////////
            /************************************************************************/
            /* 刮擦式指纹模块                                                    */
            /************************************************************************/
            /*
            //////////////////////////////////////////////////////////////////////////
            //7.获取指纹图像  8.上传指纹图像(可省略) 9.显示指纹图像(可省略) 10.生成特征B
            if (getchar(hHandle,nDevAddr,CHAR_BUFFER_C)!=1)
            { 	goto ENDERR;	 }
            //7.获取指纹图像  8.上传指纹图像(可省略) 9.显示指纹图像(可省略) 10.生成特征B
            if (getchar(hHandle,nDevAddr,CHAR_BUFFER_D)!=1)
            { 	goto ENDERR;	 }
            */
            Thread.Sleep(200);
            /****************合成模板*********/
            ret = Fingerdll.ZAZRegModule(hHandle, nDevAddr);  //合并特征
            if (ret != 0)
            { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); goto ENDERR; }
            else
            { ShowInfomation("合成指纹模板成功"); }
            Thread.Sleep(200);

            //本例以存在在指纹设备库中进行
            ret = Fingerdll.ZAZStoreChar(hHandle, nDevAddr, 1, m_Fpid);    //存放模板
            if (ret != 0)
            { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); goto ENDERR; }
            else
            { ShowInfomation("存储指纹成功"); showFpdb(); goto SUNCCESS; }



        ENDERR:
            connect_close();
            return;

        SUNCCESS:
            m_Fpid++;
            connect_close();
            return;
            /****************打开设备*********/
            //usb类型

        }

        int getchar(IntPtr hHandle, UInt32 nDevAddr, int buffer)
        {
            int ret = 0;
            byte[] ImgData = new byte[IMAGE_SIZE];
            int ImgLen = 0;
            string strFile = "";
            string sPath = "";
            int iBuffer = buffer;
            int timeout = 20;   //定义等待超时
            /****************获取图像*********/
            timeout = 20;
        BEIG1:
            ret = Fingerdll.ZAZGetImage(hHandle, nDevAddr);  //获取图象 
            if (ret == 2)
            { ShowInfomation("请将手指平放在传感器上..."); }
            else if (ret == 0)
            { ShowInfomation("获取图像成功..."); }
            else
            { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); return 0; }
            if (ret == 2)
            { //超时判断

                string strTemp;

                ShowInfomation("等待手指平放在传感器上-" + timeout.ToString() + "秒");
                if (timeout < 0)
                { ShowInfomation("等待超时"); return 0; }
                timeout--;
                Thread.Sleep(10); goto BEIG1;
            }
            if (ret != 0)
            { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); return 0; }
            //////////////////////////////////////////////////////////////////////////
            //不涉及图像，下面可以省略
            /****************上传图像*********/
            if (isusb)
            {


                ShowInfomation("正在上传图像请等待...");
                ret = Fingerdll.ZAZUpImage(hHandle, nDevAddr, ref ImgData[0], ref ImgLen);  //上传图象
                if (ret != 0)
                { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); return 0; }
                strFile = "c:\\ZAZFinger.bmp";
                ret = Fingerdll.ZAZImgData2BMP(ref ImgData[0], strFile);
                if (ret != 0)
                { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); return 0; }
                ShowImage(strFile);


            }
            //////////////////////////////////////////////////////////////////////////
            /****************生成特征 *********/

       
            ret = Fingerdll.ZAZGenChar(hHandle, nDevAddr, iBuffer);  //生成模板
            if (ret != 0)
            { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); return 0; }
            else
            { ShowInfomation("生成指纹特征" + buffer.ToString());   }
            Thread.Sleep(10);


            BEIG2:

      
            if (ret == 0)
            { //超时判断

                string strTemp;
                ret = Fingerdll.ZAZGetImage(hHandle, nDevAddr);  //获取图象 
                ShowInfomation("等待手指拿开-" );
               // if (timeout < 0)
               // { ShowInfomation("等待超时"); return 0; }
               // timeout--;
               // Thread.Sleep(10);
                goto BEIG2;
            }
            if (ret == 1)
            { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); return 0; }
            return 1;

        }

        protected bool isNumberic(string message, out int result)
        {
            //判断是否为整数字符串
            //是的话则将其转换为数字并将其设为out类型的输出值、返回true, 否则为false
            result = -1;   //result 定义为out 用来输出值
            try
            {
                //当数字字符串的为是少于4时，以下三种都可以转换，任选一种
                //如果位数超过4的话，请选用Convert.ToInt32() 和int.Parse()

                //result = int.Parse(message);
                //result = Convert.ToInt16(message);
                result = Convert.ToInt32(message);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void btn_del_Click(object sender, EventArgs e)
        {
            int ret = 0;
            UInt32 nDevAddr = 0xffffffff;
            byte[] ImgData = new byte[IMAGE_SIZE];

            int ImgLen = 0;
            string strFile = "";
            string sPath = "";
            int iBuffer = 0;
            int timeout = 20;   //定义等待超时

            IDD_Intput inputsd = new IDD_Intput();
            inputsd.ShowDialog();
            string strTemp = "";
            strTemp = inputsd.strTemp;
            if (strTemp != "") //显示输入框，接收信息，确定用户是否确定输入
            {
                string cs; //用于接收数据 
                if (isNumberic(strTemp, out m_Fpid))
                { }
                else
                {
                    MessageBox.Show("请输入数字");
                    return;
                }
            }
            else
            {
                return;
            }

            Fingerdll.ZAZCloseDeviceEx(hHandle);
            /****************打开设备*********/
            //usb类型
            if (isusb)
            {
                ret = connect_usb();
                if (ret != 0)
                { connect_close(); return; }
            }
            else
            {
                ret = connect_com(m_com, m_baud);
                if (ret != 0)
                { connect_close(); return; }
            }

            byte[] indextable = new byte[32];
            ret = Fingerdll.ZAZDelChar(hHandle, nDevAddr, m_Fpid, 1);
            if (ret != 0)
            { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); connect_close(); return; }
            else
            {

                ShowInfomation("成功删除ID:" + m_Fpid.ToString());
            }
            showFpdb();
            connect_close();

            return;
        }

        private void btn_empty_Click(object sender, EventArgs e)
        {
            int ret = 0;
            UInt32 nDevAddr = 0xffffffff;
            byte[] ImgData = new byte[IMAGE_SIZE];

            int ImgLen = 0;
            string strFile = "";
            string sPath = "";
            int iBuffer = 0;
            int timeout = 20;   //定义等待超时



            Fingerdll.ZAZCloseDeviceEx(hHandle);
            /****************打开设备*********/
            //usb类型
            if (isusb)
            {
                ret = connect_usb();
                if (ret != 0)
                { connect_close(); return; }
            }
            else
            {
                ret = connect_com(m_com, m_baud);
                if (ret != 0)
                { connect_close(); return; }
            }

            byte[] indextable = new byte[32];
            ret = Fingerdll.ZAZEmpty(hHandle, nDevAddr);
            if (ret != 0)
            { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); connect_close(); return; }
            else
            {

                ShowInfomation("清空指纹库完成");
            }
            showFpdb();
            connect_close();

            return;
        }

        private void btn_match_Click(object sender, EventArgs e)
        {
            IDD_Intput inputsd = new IDD_Intput();
            inputsd.ShowDialog();
            string strTemp = "";
            strTemp = inputsd.strTemp;
            if (strTemp != "") //显示输入框，接收信息，确定用户是否确定输入
            {
                string cs; //用于接收数据 
                if (isNumberic(strTemp, out m_Fpid))
                { }
                else
                {
                    MessageBox.Show("请输入数字");
                    return;
                }
            }
            else
            {
                return;
            }

            startMatchhread();//开启获取指纹图像和特征的线程
        }
        private void startMatchhread()
        {
            Thread thread = new Thread(new ThreadStart(matchfp));
            thread.Start();
            thread.IsBackground = true;
            if (!thread.IsAlive)
            {
                Thread.Sleep(100);
            }
        }

        private unsafe void matchfp()
        {
            int devce_usb = 0;
            int ret = 0;
            UInt32 nDevAddr = 0xffffffff;
            //	unsigned char ImgData [IMAGE_SIZE];
            int ImgLen = 0;
            string strFile = "";
            string sPath = "";
            int iBuffer = 0;
            int timeout = 20;   //定义等待超时
            int m_Addr = 1;//本例将指纹存储在设备库位置1中
            Fingerdll.ZAZCloseDeviceEx(hHandle);

            if (isusb)
            {
                ret = connect_usb();
                if (ret != 0)
                { connect_close(); return; }
            }
            else
            {
                m_com = Convert.ToInt32(textcom.Text);
                ret = connect_com(m_com, m_baud);
                if (ret != 0)
                { connect_close(); return; }
            }
            //3获取指纹图像  4.上传指纹图像(可省略) 5.显示指纹图像(可省略)  6.生成特征A  
            if (getchar(hHandle, nDevAddr, 1) != 1)
            { connect_close(); return; }
            Thread.Sleep(200);

            //7.加载指定设备中指纹 
            //本实例加载设备指纹库中1位置的指纹进行比对

            //	int fpaddress =1;
            //	ret = ZAZLoadChar(hHandle,nDevAddr,CHAR_BUFFER_B,fpaddress); 
            ret = Fingerdll.ZAZLoadChar(hHandle, nDevAddr, 2, m_Fpid);
            if (ret != 0)
            { ShowInfomation(Fingerdll.ZAZErr2Str(ret)); connect_close(); return; }
            else
            { ShowInfomation("加载指纹成功"); }
            Thread.Sleep(200);


            //8进行1:1比对
            int nScore = 0;
            ret = Fingerdll.ZAZMatch(hHandle, nDevAddr, ref nScore);  //比对模板

            if (nScore < 100)
            {
                ShowInfomation("比对得分:" + nScore.ToString());
            }
            else
            {
                ShowInfomation("比对得分:" + nScore.ToString());
            }
            connect_close();
            return;


        }

        private void btn_search_Click(object sender, EventArgs e)
        {


            startSearchhread();//开启获取指纹图像和特征的线程
        }
        private void startSearchhread()
        {
            Thread thread = new Thread(new ThreadStart(Searchfp));
            thread.Start();
            thread.IsBackground = true;
            if (!thread.IsAlive)
            {
                Thread.Sleep(100);
            }
        }

        private unsafe void Searchfp()
        {
            int devce_usb = 0;
            int ret = 0;
            UInt32 nDevAddr = 0xffffffff;
            //	unsigned char ImgData [IMAGE_SIZE];
            int ImgLen = 0;
            string strFile = "";
            string sPath = "";
            int iBuffer = 0;
            int timeout = 20;   //定义等待超时
            int m_Addr = 1;//本例将指纹存储在设备库位置1中
            Fingerdll.ZAZCloseDeviceEx(hHandle);

            if (isusb)
            {
                ret = connect_usb();
                if (ret != 0)
                { connect_close(); return; }
            }
            else
            {
                m_com = Convert.ToInt32(textcom.Text);
                ret = connect_com(m_com, m_baud);
                if (ret != 0)
                { connect_close(); return; }
            }
            //3获取指纹图像  4.上传指纹图像(可省略) 5.显示指纹图像(可省略)  6.生成特征A  
            if (getchar(hHandle, nDevAddr, 1) != 1)
            { connect_close(); return; }
            Thread.Sleep(200);

            //7.指纹库搜索比对  1:N比对 
            int nScore = 0;     //搜索得分值
            int iPageID = 0;	//搜索到的ID号
            int start_s = 0;  //从指纹库ID=0 开始搜索
            int end_s = 1000; //至指纹库ID=1000 结束搜索


           ret = Fingerdll.ZAZHighSpeedSearch(hHandle, nDevAddr, 1, start_s, end_s, ref iPageID, ref nScore);

            if (ret == 0)
            {
                ShowInfomation("找到相同手指！ID:" + iPageID.ToString() + "       得分:" + nScore.ToString());
            }
            else
            {
                ShowInfomation("未找到相同指纹");
            }
            connect_close();

        }

        private void btn_fingercount_Click(object sender, EventArgs e)
        {
            /**********************************************/
            //功能说明：本实例说明如何获取已经存在指纹模块中的指纹数量
            //流程如下：
            //1.关闭设备(可省略) 2.打开设备 3.获取模板总数  4.关闭设备
            //
            /**********************************************/

            int devce_usb = 0;
            int ret = 0;
            UInt32 nDevAddr = 0xffffffff;
            //	unsigned char ImgData [IMAGE_SIZE];
            int ImgLen = 0;
            string strFile = "";
            string sPath = "";
            int iBuffer = 0;
            int timeout = 20;   //定义等待超时
            int m_Addr = 1;//本例将指纹存储在设备库位置1中
            Fingerdll.ZAZCloseDeviceEx(hHandle);

            if (isusb)
            {
                ret = connect_usb();
                if (ret != 0)
                { connect_close(); return; }
            }
            else
            {
                m_com = Convert.ToInt32(textcom.Text);
                ret = connect_com(m_com, m_baud);
                if (ret != 0)
                { connect_close(); return; }
            }
            /****************获取模板总数*********/
            int templetNum = 0; 
            ret = Fingerdll.ZAZTemplateNum(hHandle, nDevAddr,ref templetNum);

             ShowInfomation("现有指纹数:" + templetNum.ToString() );
            /****************关闭设备*********/
            connect_close();
        }

        private void btn_dbdata_Click(object sender, EventArgs e)
        {
     /**********************************************/
            //功能说明：本实例说明如何获取已经存在指纹模块中的指纹数量
            //流程如下：
            //1.关闭设备(可省略) 2.打开设备 3.获取模板总数  4.关闭设备
            //
            /**********************************************/

            int devce_usb = 0;
            int ret = 0;
            UInt32 nDevAddr = 0xffffffff;
            //	unsigned char ImgData [IMAGE_SIZE];
            int ImgLen = 0;
            string strFile = "";
            string sPath = "";
            int iBuffer = 0;
            int timeout = 20;   //定义等待超时
            int m_Addr = 1;//本例将指纹存储在设备库位置1中
            Fingerdll.ZAZCloseDeviceEx(hHandle);

            if (isusb)
            {
                ret = connect_usb();
                if (ret != 0)
                { connect_close(); return; }
            }
            else
            {
                m_com = Convert.ToInt32(textcom.Text);
                ret = connect_com(m_com, m_baud);
                if (ret != 0)
                { connect_close(); return; }
            }
 
             showFpdb();
             connect_close();
        }

        private void BtnPCmatch_Click(object sender, EventArgs e)
        {
            startPCmatchThread();//开启获取指纹图像和特征的线程
        }
        private void startPCmatchThread()
        {
            Thread thread = new Thread(new ThreadStart(PCmatchfp));
            thread.Start();
            thread.IsBackground = true;
            if (!thread.IsAlive)
            {
                Thread.Sleep(100);
            }
        }
        private unsafe void PCmatchfp()
        {
            int ret = 0;
            int devce_usb = 0;
            UInt32 nDevAddr = 0xffffffff;
            //	unsigned char ImgData [IMAGE_SIZE];
            int ImgLen = 0;
            string strFile = "";
            string sPath = "";
            int iBuffer = 0;
            int timeout = 20;   //定义等待超时
            int m_Addr = 1;//本例将指纹存储在设备库位置1中
            Fingerdll.ZAZCloseDeviceEx(hHandle);

            if (isusb)
            {
                ret = connect_usb();
                if (ret != 0)
                { goto ENDERR; }
            }
            else
            {
                m_com = Convert.ToInt32(textcom.Text);
                ret = connect_com(m_com, m_baud);
                if (ret != 0)
                { goto ENDERR; }
            }
            //3获取指纹图像  4.上传指纹图像(可省略) 5.显示指纹图像(可省略)  6.生成特征A  
            if (getchar(hHandle, nDevAddr, 1) != 1)
            { goto ENDERR; }


            Thread.Sleep(200);
            //7.获取指纹图像  8.上传指纹图像(可省略) 9.显示指纹图像(可省略) 10.生成特征B
            if (getchar(hHandle, nDevAddr, 2) != 1)
            { goto ENDERR; }


            byte[] matchbufA = new byte[512];
            byte[] matchbufB = new byte[512];
            int lenthbuf =0;
            ret = Fingerdll.ZAZUpChar(hHandle, nDevAddr, 1, ref matchbufA[0], ref lenthbuf);
            if (ret != 0)
            { goto ENDERR; }
            ret = Fingerdll.ZAZUpChar(hHandle, nDevAddr, 2, ref matchbufB[0], ref lenthbuf);
            if (ret != 0)
            { goto ENDERR; }


            if (matchbufA[0]==0x03)
            { 
                ret = Fingerdll.Match2Fp(ref matchbufA[0], ref matchbufB[0]);
                if (ret<50)
                {
                    ShowInfomation("比对指纹失败  等分："+ ret.ToString());
                } 
                else
                {
                    ShowInfomation("比对指纹成功 等分：" + ret.ToString());
                }
            }
            else
            {

                ret = Fingerdll.CharMatch(ref matchbufA[0], ref matchbufB[0]);
                if (ret<50)
                {
                    ShowInfomation("比对指纹失败  等分："+ ret.ToString());
                } 
                else
                {
                    ShowInfomation("比对指纹成功 等分：" + ret.ToString());
                } 
            }
           
           
        ENDERR:
            connect_close();
            return; 
        }

    }
    
}
