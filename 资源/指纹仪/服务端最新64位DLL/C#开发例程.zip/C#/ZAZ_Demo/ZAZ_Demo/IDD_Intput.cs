﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ZAZ_Demo
{
    public partial class IDD_Intput : Form
    {
        public string strTemp = "";
        public IDD_Intput()
        {
            InitializeComponent();
        }

        private void buttonok_Click(object sender, EventArgs e)
        {
            strTemp = textintput.Text;
            this.Close();
        }

        private void buttonok_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                strTemp = textintput.Text;
                this.Close();
            } 
            
        }

        private void textintput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                strTemp = textintput.Text;
                this.Close();
            } 
            

        }

        private void IDD_Intput_Load(object sender, EventArgs e)
        {
            textintput.Text = "0";
        }

     
    }
}
