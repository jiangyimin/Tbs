﻿namespace ZAZ_Demo
{
    partial class IDD_Intput
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonok = new System.Windows.Forms.Button();
            this.textintput = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonok
            // 
            this.buttonok.Location = new System.Drawing.Point(108, -3);
            this.buttonok.Name = "buttonok";
            this.buttonok.Size = new System.Drawing.Size(66, 30);
            this.buttonok.TabIndex = 1;
            this.buttonok.Text = "确认";
            this.buttonok.UseVisualStyleBackColor = true;
            this.buttonok.Click += new System.EventHandler(this.buttonok_Click);
            this.buttonok.KeyDown += new System.Windows.Forms.KeyEventHandler(this.buttonok_KeyDown);
            // 
            // textintput
            // 
            this.textintput.Location = new System.Drawing.Point(2, 3);
            this.textintput.Name = "textintput";
            this.textintput.Size = new System.Drawing.Size(100, 21);
            this.textintput.TabIndex = 0;
            this.textintput.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textintput_KeyDown);
            // 
            // IDD_Intput
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(179, 29);
            this.Controls.Add(this.textintput);
            this.Controls.Add(this.buttonok);
            this.Name = "IDD_Intput";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "输入指纹";
            this.Load += new System.EventHandler(this.IDD_Intput_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonok;
        private System.Windows.Forms.TextBox textintput;
    }
}